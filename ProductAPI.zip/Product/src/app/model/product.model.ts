   
export class Product {  
    id?: number;  
    product_name?: string;  
    product_description?: string;  
    product_price?: number; 
    product_discount?: number; 
    image?:string; 
}