import { Component, OnInit } from '@angular/core';
import { productService } from '../service/product.service';  
import {  Product } from '../model/product.model';  
import { Router } from "@angular/router";  
import {DomSanitizer} from '@angular/platform-browser';
 
@Component({
  selector: 'app-list-prodcut',
  templateUrl: './list-prodcut.component.html',
  styleUrls: ['./list-prodcut.component.css']
})
export class ListProdcutComponent implements OnInit {

  productlst: Product[];  
  public _DomSanitizer: DomSanitizer
  constructor(private prodService: productService, private router: Router, ) { }  
  
  ngOnInit() {  
    this.prodService.getproducts().subscribe((data: Product[]) => {  
        this.productlst = data;  
      }); 

      
  }  
  deleteEmp(product: Product): void {  
    this.prodService.deleteproducts(product.id)  
      .subscribe(data => {this.productlst = this.productlst.filter(u => u !== product);  
      })  
  }  
  editEmp(product: Product): void {  
    localStorage.removeItem('editEmpId');  
    localStorage.setItem('editEmpId', product.id.toString());  
    this.router.navigate(['add-emp']);  
  }  

}
