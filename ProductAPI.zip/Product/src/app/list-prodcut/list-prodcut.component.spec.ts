import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListProdcutComponent } from './list-prodcut.component';

describe('ListProdcutComponent', () => {
  let component: ListProdcutComponent;
  let fixture: ComponentFixture<ListProdcutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListProdcutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListProdcutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
