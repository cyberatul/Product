import { Injectable } from '@angular/core';  
import { HttpClient } from '@angular/common/http';  
import { Product } from '../model/product.model' ;  
  
@Injectable({  
  providedIn: 'root'  
})  
export class productService {  
  
  constructor(private http: HttpClient) { }  
  baseUrl: string = 'http://localhost:49514/api/product';  
  
  getproducts() {  
    return this.http.get<Product[]>(this.baseUrl);  
  /* var prodlst:Product[]=[
{"id":1, "product_name":"Prod 1","product_description":"this my 1","product_price":20,"product_discount":1},
{"id":2, "product_name":"Prod 2","product_description":"this my 2","product_price":20,"product_discount":1},
{"id":3, "product_name":"Prod 3","product_description":"this my 3","product_price":20,"product_discount":1}
   ];
   return prodlst;*/
  }  
  deleteproducts(id: number) {  
    return this.http.delete<Product[]>(this.baseUrl + id);  
  }  
  createUser(product: Product) {  
    return this.http.post(this.baseUrl, product);  
  }  
  getproductById(id: number) {  
    return this.http.get<Product>(this.baseUrl + '/' + id);  
  }  
  updateproduct(product: Product) {  
    return this.http.put(this.baseUrl + '/' + product.id, product);  
  }  
}  