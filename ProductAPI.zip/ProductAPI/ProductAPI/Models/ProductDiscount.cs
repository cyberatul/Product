﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductAPI.Models
{
    public class ProductDiscount
    {
        public int id { get; set; }
        public int prodcut_id { get; set; }
        public int product_discount { get; set; }
        public DateTime date { get; set; }
    }
}