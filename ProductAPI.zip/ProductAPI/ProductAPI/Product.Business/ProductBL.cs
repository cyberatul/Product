﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ProductAPI.Models;

namespace ProductAPI.Business
{
    public class ProductBL
    {
        /// <summary>
        /// Read product from CSV and return 
        /// </summary>
        /// <returns></returns>

        public List<Product> GetProduct()
        {
          
            string product_csv = Utility.Utility.File.PRODUCT_CSV;
            string[] csvlines = System.IO.File.ReadAllLines(product_csv);

            // skip header
            var productlst = from csvline in csvlines.Skip(1)
                             let data = csvline.Split(',')
                             select new Product
                             {
                                 id = int.Parse(data[0]),
                                 product_name = data[1],
                                 product_description = data[2],
                                 product_price = int.Parse(data[3]),
                                 image = data[4]
                             };

            //Get all product discount list for current date
            var discountlst = GetDiscount().Where(x => x.date.Date == System.DateTime.Now.Date);

            //Get product with current discount
            var product_discountlst = from plst in productlst
                                   join disc in discountlst on plst.id equals disc.prodcut_id into dj
                                   from sub_dj in dj.DefaultIfEmpty()
                                   select new Product
                                   {
                                       id = plst.id,

                                       product_name = plst.product_name,
                                       product_description = plst.product_description,
                                       product_price = plst.product_price,
                                       image = plst.image,
                                       product_discount = sub_dj?.product_discount??0
                                   };
            return product_discountlst.ToList();


        }

        /// <summary>
        /// Read product from CSV and return 
        /// </summary>
        /// <returns></returns>


        public List<ProductDiscount> GetDiscount()
        {

            string discount_csv = Utility.Utility.File.DISCOUNT_CSV;
            string[] csvlines = System.IO.File.ReadAllLines(discount_csv);

            // skip header
            var query = from csvline in csvlines.Skip(1)
                        let data = csvline.Split(',')
                        select new ProductDiscount
                        {
                            id = int.Parse(data[0]),
                            prodcut_id = int.Parse(data[1]),
                            date =Convert.ToDateTime( data[2]),
                            product_discount = int.Parse(data[3]),
                            
                        };
            return query.ToList();


        }

    }
}