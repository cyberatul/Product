﻿using System;
using System.Configuration;
using System.IO;

[assembly: log4net.Config.XmlConfigurator(ConfigFile = "log4net.config", Watch = true)]
//[assembly: log4net.Config.Repository("CommEuSecurityService")]
[assembly: log4net.Config.Repository("LOG")]

namespace Logging
{
    public static class Logger
    {
        static Logger()
        {
            var LogPath = Convert.ToString(ConfigurationManager.AppSettings["LogPath"]);
            //var LogPath = "LOG";
            var log4NetConfigFilePath = Path.Combine(LogPath.ToString(), "log4net.config");
            log4net.Config.XmlConfigurator.ConfigureAndWatch(new FileInfo(log4NetConfigFilePath));
        }

        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static void Debug(string message, Exception exception)
        {
            Log.Debug(message, exception);
        }

        public static void Debug(string message)
        {
            Log.Debug(message);
        }

        public static void Error(string message, Exception exception)
        {
            Log.Error(message, exception);
        }

        public static void Error(string message)
        {
            try
            {
                Log.Error(message);
            }
            catch (Exception ex)
            {
                string str = ex.ToString();
            }
        }

        public static void Info(string message, Exception exception)
        {
            Log.Info(message, exception);
        }

        public static void Info(string message)
        {
            Log.Info(message);
        }

        public static void Info(string userName, string message)
        {
            message = string.Format("{0} - {1}", userName, message);
            Log.Info(message);
        }
        
    }
}