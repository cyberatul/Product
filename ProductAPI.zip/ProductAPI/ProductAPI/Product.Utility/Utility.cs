﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductAPI.Utility
{
    public class Utility
    {
        public static class File
        {
            public static readonly string PRODUCT_CSV = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["ProductCSV"]);
            public static readonly string DISCOUNT_CSV = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["DiscountCSV"]);
        }
    }
}