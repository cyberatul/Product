﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Results;
using Logging;
using LumenWorks.Framework.IO.Csv;
using ProductAPI.Business;
using ProductAPI.Filter;
using ProductAPI.Models;

namespace ProductAPI.Controllers
{
    public class ProductController : ApiController
    {
        private ProductBL _productBL;
        public ProductController()
        {
            _productBL = new ProductBL();
        }
        [HttpGet]
        [ProductExceptionFilter]
        [Route("Product/GetProduct")]
        [Authorize]
        public IHttpActionResult GetProduct()
        {
            try
            {
                int i = Convert.ToInt16("eer");
                return Ok(_productBL.GetProduct());
            }
            catch(Exception ex)
            {
                Logger.Error(String.Format("MethodName {0},", "GetProdcut-" + ex.Message));
                var resp = new HttpResponseMessage(HttpStatusCode.NotFound)
                {
                    Content = new StringContent(string.Format("No Data Found")),
                    ReasonPhrase = "Data Not Found"
                };
                throw new HttpResponseException(resp);
                 
            }
        }
        [HttpGet]
        [ProductExceptionFilter]
        [Route("Product/GetDisount")]
        public IHttpActionResult GetDisount()
        {
            try
            {
                return Ok(_productBL.GetDiscount());
            }
            catch (Exception ex)
            {
                Logger.Error(String.Format("MethodName {0}, Message {1}, Status {2}", "GetDiscount", ex.Message, "Error"));
                var resp = new HttpResponseMessage(HttpStatusCode.NotFound)
                {
                    Content = new StringContent(string.Format("No Data Found")),
                    ReasonPhrase = "Data Not Found"
                };
                throw new HttpResponseException(resp);

            }

        }


    }
}
